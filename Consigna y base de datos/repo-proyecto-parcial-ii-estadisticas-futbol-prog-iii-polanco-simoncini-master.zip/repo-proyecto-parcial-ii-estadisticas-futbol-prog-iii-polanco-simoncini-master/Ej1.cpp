#include <iostream>
using namespace std;

int main() {

    cout << "Ejercicio N° 1" << endl;

    return 0;
}
