# Pilas en C++

Una pila es una colección ordenada de
elementos en la que pueden insertarse y
suprimirse elementos por un extremo
llamado TOPE.

## Clase

### Metodos

Constructor()
Destructor()

esVacia()
push( dato )
pop()
