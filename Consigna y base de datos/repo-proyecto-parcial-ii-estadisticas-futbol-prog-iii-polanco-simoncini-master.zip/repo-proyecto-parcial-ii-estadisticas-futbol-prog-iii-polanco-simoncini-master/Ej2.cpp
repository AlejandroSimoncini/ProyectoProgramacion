#include <iostream>
using namespace std;

int main() {

    cout << "Ejercicio N° 2" << endl;

    return 0;
}
